timelines
=========

timelines is a LaTeX package for drawing timeline diagrams, based on the TikZ
drawing package.


Documentation
-------------

See timelines.pdf for the details on how to use this package.


License
-------

timelines is free software licensed under the MIT License. See LICENSE.txt for
the details.

